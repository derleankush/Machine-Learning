PKL_FILE_PATH = "\project_app\CollegePlace.pkl"
JSON_FILE_PATH = "\project_app\JsonFile.json"